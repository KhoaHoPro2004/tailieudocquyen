import React from 'react';
import type { Folder } from '../types';

const FolderIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5} {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z" />
  </svg>
);

interface FolderItemProps {
  folder: Folder;
}

const FolderItem: React.FC<FolderItemProps> = ({ folder }) => {
  return (
    <a 
      href={folder.href} 
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center p-3 bg-white hover:bg-blue-100 rounded-xl shadow-sm border border-gray-200 hover:border-blue-300 hover:shadow-md transform hover:-translate-y-1 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
    >
      <FolderIcon className="h-6 w-6 text-gray-500 mr-4 flex-shrink-0" />
      <span className="text-sm font-medium text-gray-800 truncate">{folder.name}</span>
    </a>
  );
};

export default FolderItem;