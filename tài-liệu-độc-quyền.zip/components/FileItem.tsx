import React from 'react';
import { FileItem, FileType } from '../types';

const DocumentIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0016.5 9h-1.875a.375.375 0 01-.375-.375V6.75A3.75 3.75 0 009 3H5.625z" />
    <path d="M12.75 1.5v3.75a.375.375 0 01-.375.375h-3.75a.375.375 0 01-.375-.375V1.5h4.5z" />
  </svg>
);

const PresentationIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
     <path d="M2.25 2.25a.75.75 0 00-.75.75v18a.75.75 0 00.75.75h19.5a.75.75 0 00.75-.75V3a.75.75 0 00-.75-.75H2.25zM6 6a.75.75 0 01.75-.75h10.5a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75H6.75a.75.75 0 01-.75-.75V6z" />
  </svg>
);

const ImageIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0021 18v-1.94l-2.69-2.689a1.5 1.5 0 00-2.12 0l-.88.879.97.97a.75.75 0 11-1.06 1.06l-5.16-5.159a1.5 1.5 0 00-2.12 0L3 16.061zm10.125-7.81a1.125 1.125 0 112.25 0 1.125 1.125 0 01-2.25 0z" clipRule="evenodd" />
  </svg>
);

const FileTypeIcon: React.FC<{ type: FileType }> = ({ type }) => {
  switch (type) {
    case FileType.DOCUMENT:
      return <DocumentIcon className="h-6 w-6 text-blue-600 mr-4 flex-shrink-0" />;
    case FileType.PRESENTATION:
      return <PresentationIcon className="h-6 w-6 text-red-500 mr-4 flex-shrink-0" />;
    case FileType.IMAGE:
      return <ImageIcon className="h-6 w-6 text-red-500 mr-4 flex-shrink-0" />;
    default:
      return null;
  }
};

interface FileItemProps {
  file: FileItem;
}

const FileItem: React.FC<FileItemProps> = ({ file }) => {
  return (
    <a 
      href={file.href}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center p-3 bg-white hover:bg-blue-100 rounded-xl shadow-sm border border-gray-200 hover:border-blue-300 hover:shadow-md transform hover:-translate-y-1 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
    >
      <FileTypeIcon type={file.type} />
      <span className="text-sm font-medium text-gray-800 truncate">{file.name}</span>
    </a>
  );
};

export default FileItem;